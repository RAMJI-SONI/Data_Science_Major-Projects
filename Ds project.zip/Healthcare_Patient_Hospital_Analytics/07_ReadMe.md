# Project 4: Healthcare Patient & Hospital Analytics

## Project Title
Healthcare Patient & Hospital Analytics using the UCI Diabetes 130-US Hospitals Dataset

## Business Problem
Hospital management needs a transparent view of patient demographics, utilization, length of stay, readmission patterns, treatment/medication activity, and operational workload. This project analyzes a public, de-identified historical dataset and does not provide medical advice.

## Business Objective
- Describe patient and encounter volumes across age groups, admission types, and diagnoses.
- Quantify length of stay, procedure/lab/medication activity, and readmission patterns.
- Identify records and groups that merit operational review, without implying clinical causation.
- Build reproducible Excel, SQL, Python, and Power BI workflows.

## Stakeholders
Hospital operations managers, quality-improvement teams, finance/analytics teams, department managers, and data governance/privacy reviewers.

## Dataset Source
UCI Machine Learning Repository — Diabetes 130-US Hospitals for Years 1999–2008:
https://archive.ics.uci.edu/dataset/296/diabetes-130-us-hospitals-for-years-1999-2008
Dataset includes 101,766 encounter records from 130 US hospitals/integrated delivery networks, with data from 1999–2008. Each row is a hospital encounter for a patient diagnosed with diabetes; it is not a complete representation of all hospital patients. Cite the UCI dataset and its CC BY 4.0 license when reusing it.

## Tools Used
Excel, SQL (PostgreSQL-compatible), Python (pandas, numpy, matplotlib, seaborn), Jupyter Notebook, and Power BI Desktop.

## Data Cleaning Process
1. Obtain `diabetic_data.csv` and `IDS_mapping.csv` from the UCI dataset page.
2. Preserve the original files unchanged and work on copies.
3. Standardize column names to lowercase; trim whitespace.
4. Treat the literal string `?` as missing; report missingness before deciding whether to drop or impute.
5. Keep `encounter_id` as encounter key and `patient_nbr` as a repeat-patient identifier. Do not count each encounter as a unique person.
6. Validate numeric fields such as `time_in_hospital`, `num_lab_procedures`, `num_procedures`, and `num_medications`.
7. Flag—not automatically delete—outliers for review. A long stay or high procedure count may be valid.
8. Map admission/discharge/source IDs only with the official `IDS_mapping.csv`; unknown mappings remain labelled `Unknown / unmapped`.
9. Exclude duplicate encounter IDs only after checking and documenting duplicate records.
10. Avoid using demographic groups to make individual clinical decisions.

## Key Business Questions
1. Which patient groups generate the highest utilization?
2. What are the most common medical conditions?
3. Which treatments/departments have the highest patient volume?
4. What factors are associated with longer hospital stays?
5. What is the average cost or utilization per patient?
6. Which patient segments require the greatest operational attention?
7. Are there unusual or outlier patient records?

## Major Findings
**Do not enter findings until the official dataset has been loaded and the notebook/SQL outputs have been run.** The project intentionally avoids inventing statistics. Use the generated analysis outputs to populate the report and presentation.

## Business Recommendations (to validate against computed results)
- Plan staffing and capacity using encounter volumes, admission type, length of stay, and procedure workload.
- Review long-stay and repeat-encounter records with operational teams; do not assume an outlier is an error.
- Compare readmission rates across descriptive segments while reporting sample sizes and uncertainty.
- Use department/specialty analysis cautiously: `medical_specialty` may be missing and is not a complete department identifier.
- Use actual cost data if available. This dataset does not contain a direct hospital-cost field; do not label procedure counts or length of stay as monetary cost.
- Protect privacy, suppress small cells where appropriate, and avoid clinical claims unsupported by this historical dataset.

## Limitations
- Historical US data from 1999–2008; it may not reflect current care or other countries.
- Only diabetes-related inpatient encounters meeting the dataset's inclusion criteria are represented.
- No direct hospital cost field; cost per patient cannot be calculated from this dataset alone.
- Medical specialty is not equivalent to a hospital department.
- Missing values and coded IDs require careful handling.
- Observational associations are not evidence of causation.
- This is an educational analytics project, not a clinical decision-support system.

## Run Instructions
1. Download the two CSV files from the UCI page above.
2. Put them in `data/` in the project folder (create that folder if needed).
3. Install packages: `pip install -r requirements.txt`.
4. Open `notebook/04_Python_EDA.ipynb` in Jupyter and run all cells.
5. Run `sql/03_SQL_Queries.sql` after importing the CSV into PostgreSQL using the schema in that file.
6. Open `powerbi/PowerBI_Build_Guide.md`, import the cleaned CSV produced by the notebook, and save the finished report as `05_PowerBI_Dashboard.pbix` in Power BI Desktop.
7. Refresh the Excel analysis workbook with computed outputs. It includes a workbook structure, KPI definitions, and formulas/queries to complete.

## Citation
Clore, J., Cios, K., DeShazo, J., & Strack, B. (2014). Diabetes 130-US Hospitals for Years 1999–2008 [Dataset]. UCI Machine Learning Repository. DOI: 10.24432/C5230J.
