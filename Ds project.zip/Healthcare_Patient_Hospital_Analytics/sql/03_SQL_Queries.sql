/*
PROJECT 4 — HEALTHCARE PATIENT & HOSPITAL ANALYTICS
Dataset: UCI Diabetes 130-US Hospitals for Years 1999–2008
Dialect: PostgreSQL 14+
Import diabetic_data.csv into public.diabetic_data_raw.
CSV values '?' should be imported as text first, or NULLIF(value, '?') applied.
Never interpret encounter counts as unique patients.
*/

-- 0. Recommended staging table. To avoid fragile CSV type inference, import raw CSV
-- columns as TEXT, then cast selected fields in a view.
-- CREATE TABLE public.diabetic_data_raw (... all source columns ...);

-- 1. Data profile / row count
SELECT COUNT(*) AS encounter_rows,
       COUNT(DISTINCT encounter_id) AS distinct_encounters,
       COUNT(DISTINCT patient_nbr) AS distinct_patients
FROM public.diabetic_data_raw;

-- 2. Duplicate encounter IDs (investigate before removing)
SELECT encounter_id, COUNT(*) AS row_count
FROM public.diabetic_data_raw
GROUP BY encounter_id
HAVING COUNT(*) > 1
ORDER BY row_count DESC;

-- 3. Missingness for key fields ('?' is the source missing marker)
SELECT
  COUNT(*) AS total_rows,
  COUNT(*) FILTER (WHERE race IS NULL OR race = '?') AS missing_race,
  COUNT(*) FILTER (WHERE medical_specialty IS NULL OR medical_specialty = '?') AS missing_specialty,
  COUNT(*) FILTER (WHERE payer_code IS NULL OR payer_code = '?') AS missing_payer,
  COUNT(*) FILTER (WHERE diag_1 IS NULL OR diag_1 = '?') AS missing_primary_diagnosis
FROM public.diabetic_data_raw;

-- 4. Create a typed analytical view. Raw table columns are assumed to be text.
CREATE OR REPLACE VIEW public.diabetic_data AS
SELECT
  NULLIF(encounter_id, '?')::BIGINT AS encounter_id,
  NULLIF(patient_nbr, '?')::BIGINT AS patient_nbr,
  NULLIF(race, '?') AS race,
  NULLIF(gender, '?') AS gender,
  NULLIF(age, '?') AS age_group,
  NULLIF(admission_type_id, '?')::INT AS admission_type_id,
  NULLIF(discharge_disposition_id, '?')::INT AS discharge_disposition_id,
  NULLIF(admission_source_id, '?')::INT AS admission_source_id,
  NULLIF(time_in_hospital, '?')::INT AS time_in_hospital,
  NULLIF(NULLIF(medical_specialty, '?'), 'Unknown') AS medical_specialty,
  NULLIF(num_lab_procedures, '?')::INT AS num_lab_procedures,
  NULLIF(num_procedures, '?')::INT AS num_procedures,
  NULLIF(num_medications, '?')::INT AS num_medications,
  NULLIF(number_outpatient, '?')::INT AS number_outpatient,
  NULLIF(number_emergency, '?')::INT AS number_emergency,
  NULLIF(number_inpatient, '?')::INT AS number_inpatient,
  NULLIF(diag_1, '?') AS diag_1,
  NULLIF(diag_2, '?') AS diag_2,
  NULLIF(diag_3, '?') AS diag_3,
  NULLIF(number_diagnoses, '?')::INT AS number_diagnoses,
  NULLIF(readmitted, '?') AS readmitted,
  NULLIF(diabetesMed, '?') AS diabetes_medication,
  NULLIF(insulin, '?') AS insulin_change,
  NULLIF(A1Cresult, '?') AS a1c_result,
  NULLIF(max_glu_serum, '?') AS max_glucose_result
FROM public.diabetic_data_raw;

-- 5. Highest-utilization age groups (encounters, LOS, lab and medication workload)
SELECT age_group,
       COUNT(*) AS encounters,
       COUNT(DISTINCT patient_nbr) AS distinct_patients,
       ROUND(AVG(time_in_hospital)::NUMERIC, 2) AS avg_los_days,
       ROUND(AVG(num_lab_procedures)::NUMERIC, 2) AS avg_lab_procedures,
       ROUND(AVG(num_medications)::NUMERIC, 2) AS avg_medications
FROM public.diabetic_data
GROUP BY age_group
ORDER BY encounters DESC;

-- 6. Most common primary diagnosis codes (codes are not interpreted as diagnoses here)
SELECT diag_1 AS primary_diagnosis_code, COUNT(*) AS encounters
FROM public.diabetic_data
WHERE diag_1 IS NOT NULL
GROUP BY diag_1
ORDER BY encounters DESC
LIMIT 15;

-- 7. Specialty workload (not a direct department measure)
SELECT COALESCE(medical_specialty, 'Missing / unknown') AS specialty,
       COUNT(*) AS encounters,
       ROUND(AVG(time_in_hospital)::NUMERIC, 2) AS avg_los_days,
       ROUND(AVG(num_lab_procedures)::NUMERIC, 2) AS avg_lab_procedures
FROM public.diabetic_data
GROUP BY COALESCE(medical_specialty, 'Missing / unknown')
ORDER BY encounters DESC
LIMIT 20;

-- 8. Factors associated with longer stays (descriptive association only)
SELECT age_group,
       admission_type_id,
       COUNT(*) AS encounters,
       ROUND(AVG(time_in_hospital)::NUMERIC, 2) AS avg_los_days,
       ROUND(AVG(num_procedures)::NUMERIC, 2) AS avg_procedures,
       ROUND(AVG(num_lab_procedures)::NUMERIC, 2) AS avg_lab_procedures,
       ROUND(AVG(num_medications)::NUMERIC, 2) AS avg_medications
FROM public.diabetic_data
GROUP BY age_group, admission_type_id
HAVING COUNT(*) >= 30
ORDER BY avg_los_days DESC;

-- 9. Readmission mix
SELECT readmitted, COUNT(*) AS encounters,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_of_encounters
FROM public.diabetic_data
GROUP BY readmitted
ORDER BY encounters DESC;

-- 10. Readmission by age group
SELECT age_group, readmitted, COUNT(*) AS encounters
FROM public.diabetic_data
GROUP BY age_group, readmitted
ORDER BY age_group, readmitted;

-- 11. Repeat utilization in the year before the encounter
SELECT
  CASE WHEN COALESCE(number_inpatient,0) = 0 THEN '0'
       WHEN number_inpatient = 1 THEN '1'
       ELSE '2+' END AS prior_inpatient_group,
  COUNT(*) AS encounters,
  ROUND(AVG(time_in_hospital)::NUMERIC, 2) AS avg_los_days,
  ROUND(100.0 * COUNT(*) FILTER (WHERE readmitted = '<30') / COUNT(*), 2) AS readmitted_under_30_pct
FROM public.diabetic_data
GROUP BY 1
ORDER BY 1;

-- 12. Outlier review using IQR for length of stay; flags only, never auto-deletes
WITH bounds AS (
  SELECT percentile_cont(0.25) WITHIN GROUP (ORDER BY time_in_hospital) AS q1,
         percentile_cont(0.75) WITHIN GROUP (ORDER BY time_in_hospital) AS q3
  FROM public.diabetic_data
)
SELECT d.encounter_id, d.patient_nbr, d.age_group, d.time_in_hospital,
       d.num_lab_procedures, d.num_procedures, d.num_medications,
       'LOS IQR outlier — review record context' AS review_flag
FROM public.diabetic_data d CROSS JOIN bounds b
WHERE d.time_in_hospital < b.q1 - 1.5*(b.q3-b.q1)
   OR d.time_in_hospital > b.q3 + 1.5*(b.q3-b.q1)
ORDER BY d.time_in_hospital DESC;

-- 13. Explicitly document cost limitation: the source has no direct cost field.
-- Do not compute currency cost from LOS or procedure counts without external cost data.
