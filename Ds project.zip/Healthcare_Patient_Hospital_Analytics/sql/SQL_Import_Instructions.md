# PostgreSQL Import Instructions

1. Create a database: `CREATE DATABASE healthcare_analytics;`
2. In pgAdmin, select the database and create `public.diabetic_data_raw` using the source CSV's 50 columns. Easiest beginner workflow: use pgAdmin Import/Export on a table created with source column names, setting all columns to `TEXT`.
3. Import `diabetic_data.csv` with header enabled. Keep `?` as text or normalize it to NULL consistently.
4. Run `03_SQL_Queries.sql`.
5. If your source version has slightly different column names/casing, inspect `information_schema.columns` and adjust the staging import before running the typed view.
6. Never run the typed view against a table whose columns are already integer types if your SQL tool errors on comparisons to '?'; in that case remove the `= '?'` checks for already-typed numeric columns.
