# Power BI Dashboard Build Guide

**Important:** A native `.pbix` must be created and saved from Microsoft Power BI Desktop. This package provides the model, measures, and page plan; it does not mislabel a text file as a PBIX.

## Data import
1. Run the Python notebook and export `diabetes_cleaned.csv`.
2. In Power BI Desktop: Get Data → Text/CSV → select `diabetes_cleaned.csv`.
3. Confirm types: encounter_id/patient_nbr as Whole Number; time_in_hospital and procedure/medication counts as Whole Number; categories as Text.
4. Name the imported table `Encounters`.
5. If loading raw source data instead, replace `?` with null and apply equivalent transformations in Power Query.

## Suggested measures (DAX)
```DAX
Encounter Count = COUNTROWS(Encounters)

Unique Patients = DISTINCTCOUNT(Encounters[patient_nbr])

Average Length of Stay =
AVERAGE(Encounters[time_in_hospital])

Total Inpatient Days =
SUM(Encounters[time_in_hospital])

Average Lab Procedures =
AVERAGE(Encounters[num_lab_procedures])

Average Procedures =
AVERAGE(Encounters[num_procedures])

Average Medications =
AVERAGE(Encounters[num_medications])

Readmitted Under 30 Days =
CALCULATE(
    [Encounter Count],
    Encounters[readmitted] = "<30"
)

Readmission Under 30 Rate =
DIVIDE([Readmitted Under 30 Days], [Encounter Count], 0)

Readmitted After 30 Days =
CALCULATE([Encounter Count], Encounters[readmitted] = ">30")

Not Readmitted =
CALCULATE([Encounter Count], Encounters[readmitted] = "NO")
```

## Pages and visuals
### Page 1 — Executive Overview
- KPI cards: Encounter Count, Unique Patients, Average Length of Stay, Readmission Under 30 Rate.
- Bar chart: encounter count by age group.
- Donut chart: readmitted outcome (`<30`, `>30`, `NO`).
- Slicers: age group, gender, race, admission type, readmitted.

### Page 2 — Utilization & Capacity
- Bar chart: encounters by medical specialty (top 10/15; include missing category).
- Bar chart: average length of stay by age group.
- Scatter plot: number of lab procedures vs. length of stay; tooltip includes medication/procedure counts.
- Table: admission type, encounter count, average LOS, average labs, average medications.

### Page 3 — Diagnosis & Treatment Activity
- Bar chart: most frequent primary diagnosis codes (codes only unless a validated ICD-9 mapping is joined).
- Bar chart: average medication count by diabetes medication status.
- Matrix: age group × readmitted outcome, with encounter counts and row percentages.

### Page 4 — Data Quality & Outliers
- Cards: missing race, missing specialty, missing primary diagnosis.
- Table: flagged long stays and high utilization records.
- State clearly that outliers are review flags, not errors or clinical risk classifications.

## Model and quality checks
- Keep one row per encounter; `patient_nbr` repeats across encounters.
- Do not join on patient_nbr alone to encounter-level tables unless intended.
- Confirm the sum of readmission categories equals encounter count (excluding nulls only if explicitly documented).
- Use consistent filters and report denominator in percentage visuals.
- No cost KPI: source dataset has no direct cost field.
- Do not infer causality or clinical advice from descriptive associations.

## Save final deliverable
Save from Power BI Desktop as `05_PowerBI_Dashboard.pbix`. Include screenshots or exported PDF if your instructor needs a preview.
