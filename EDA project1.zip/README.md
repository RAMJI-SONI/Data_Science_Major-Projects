# Project 01 — E-Commerce Sales & Customer Behavior Analysis

## Objective
Analyze sales performance, product demand, customer purchasing behavior, country-level revenue, time trends, cancellations and returns.

## Dataset
- UCI Online Retail: https://archive.ics.uci.edu/dataset/352/online+retail
- File: `Online Retail.xlsx`
- Original size: 541,909 transaction-line records; 1 December 2010–9 December 2011.
- Columns: InvoiceNo, StockCode, Description, Quantity, InvoiceDate, UnitPrice, CustomerID, Country.
- License: CC BY 4.0. Attribute the source in any redistributed work.

## Setup
1. Download `Online Retail.xlsx` from the UCI page.
2. Place it next to `Ecommerce_Sales_Customer_Behavior_EDA.ipynb`.
3. Run `pip install -r requirements.txt`.
4. Open the notebook in Jupyter and run all cells. It also attempts optional retrieval via `ucimlrepo` if the local file is missing and network access is available.

## Questions investigated
1. Which products generate the highest sales?
2. Which countries contribute the most revenue?
3. What are the monthly sales trends?
4. Which products have the highest quantity sold?
5. What is the average order value?
6. Who are the most valuable customers?
7. Are there unusual transactions or outliers?
8. What percentage of transactions are cancelled?
9. Which products show increasing or declining demand?
10. Is there a relationship between product price and quantity purchased?

## Workflow
Data understanding; missing/duplicate checks; date parsing; cancellation and return flags; univariate, bivariate and multivariate EDA; time-series analysis; product/customer/country analysis; correlations and outlier review; insights and recommendations.

## Metric definitions
- Line revenue = Quantity × UnitPrice, in GBP (£).
- InvoiceNo beginning with C indicates a cancellation.
- Core sales metrics use positive quantity and price, excluding cancellation invoices; returns/cancellations are separately analyzed.
- Average order value is calculated from line revenue summed by invoice under that filter.
- Customer value reflects historical revenue for identified customers, not a forecast.
- The data is historical (2010–2011), not a representation of current retail behavior.
