# Project 02 — Employee Attrition & Workplace Analytics

## Project objective
Analyze employee demographics, compensation, job characteristics, satisfaction, overtime, and tenure to understand patterns associated with employee attrition and provide evidence-based HR recommendations.

## Dataset
**IBM HR Analytics Employee Attrition & Performance** (fictional/synthetic dataset created by IBM data scientists).

- Kaggle source: https://www.kaggle.com/datasets/pavansubhasht/ibm-hr-analytics-attrition-dataset
- Expected file: `WA_Fn-UseC_-HR-Employee-Attrition.csv`
- Expected shape: 1,470 rows × 35 columns.
- Target: `Attrition` (`Yes` = employee left; `No` = employee stayed).

### Get the dataset
1. Open the Kaggle dataset page above and download the dataset ZIP/CSV (a Kaggle login may be required).
2. Extract `WA_Fn-UseC_-HR-Employee-Attrition.csv`.
3. Put the CSV in the same folder as `Employee_Attrition_EDA.ipynb`.
4. Open the notebook in Jupyter Notebook, JupyterLab, or Google Colab and run all cells.

## Questions investigated
1. What is the overall attrition rate?
2. Which departments have higher attrition?
3. Is overtime associated with attrition?
4. Do salary and income differ between employees who left and stayed?
5. How does job satisfaction relate to attrition?
6. Does distance from home have a relationship with attrition?
7. Which job roles have higher attrition?
8. Does age influence attrition patterns?
9. How does work-life balance relate to attrition?
10. What differences are observed between employees who left and those who stayed?

## Workflow completed in the notebook
- Data understanding: shape, columns, data types, descriptive statistics and business questions.
- Data cleaning: duplicate checks, missing-value checks, constant-column checks, data type review, and a clean analysis copy.
- Exploratory analysis: univariate, bivariate, multivariate and categorical analysis, correlations and IQR outlier review.
- Visualizations: 3+ histograms, 3+ bar charts, 2+ box plots, 2+ count plots, 2 scatter plots, 1 correlation heatmap, 1 time-series chart where applicable, and 2 additional meaningful visualizations.
- Insights and recommendations: notebook-generated findings plus interpretation guidance.

## Important interpretation notes
- The dataset is synthetic; findings should not be treated as proof of causal relationships or as representative of every organization.
- This is an imbalanced target: the `Yes` group is much smaller than the `No` group. Compare rates, not only raw counts.
- `EmployeeCount`, `EmployeeNumber`, `Over18`, and `StandardHours` are non-informative for most analyses and are excluded from the analysis copy, but the original raw data is preserved.
- Outliers are flagged for investigation rather than automatically deleted.
- Correlation does not establish causation. Recommendations should be validated with real organizational data and employee feedback.

## Deliverables
- `Employee_Attrition_EDA.ipynb` — analysis, code, visualizations and findings.
- `README.md` — project description and instructions.
- `EDA_Report.pdf` — report framework and interpretation guide.
- `Project_Presentation.pptx` — 8-slide presentation.
- `requirements.txt` — Python dependencies.
- `DATASET_DOWNLOAD.txt` — dataset source and setup steps.
