-- =====================================================
-- PROJECT 01: E-Commerce Sales & Customer Analytics
-- All analysis queries (PostgreSQL)
-- =====================================================
-- Definitions used throughout:
--   Revenue       = SUM(order_items.price)  (product sales, excluding freight)
--   Valid orders  = order_status NOT IN ('canceled','unavailable')
--   Delivered     = order_status = 'delivered' AND delivery date is not null
-- =====================================================


-- =====================================================
-- Q1. Total number of orders and total revenue
-- Skills: aggregate functions, JOIN, subquery-free filtering
-- =====================================================
SELECT
    COUNT(DISTINCT o.order_id)                      AS total_orders,
    ROUND(SUM(oi.price), 2)                         AS total_revenue,
    ROUND(SUM(oi.price + oi.freight_value), 2)      AS total_revenue_incl_freight
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.order_status NOT IN ('canceled', 'unavailable');


-- =====================================================
-- Q2a. Monthly sales trend
-- Skills: date functions, GROUP BY, JOIN
-- =====================================================
SELECT
    DATE_TRUNC('month', o.order_purchase_timestamp)::date AS month,
    COUNT(DISTINCT o.order_id)                            AS orders,
    ROUND(SUM(oi.price), 2)                               AS revenue
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY 1
ORDER BY 1;

-- Q2b. Yearly sales trend
SELECT
    EXTRACT(YEAR FROM o.order_purchase_timestamp)::int AS year,
    COUNT(DISTINCT o.order_id)                         AS orders,
    ROUND(SUM(oi.price), 2)                            AS revenue
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY 1
ORDER BY 1;

-- Q2c. Month-over-month growth (CTE + window function LAG)
WITH monthly AS (
    SELECT DATE_TRUNC('month', o.order_purchase_timestamp)::date AS month,
           SUM(oi.price) AS revenue
    FROM orders o
    JOIN order_items oi ON oi.order_id = o.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY 1
)
SELECT
    month,
    ROUND(revenue, 2) AS revenue,
    ROUND(LAG(revenue) OVER (ORDER BY month), 2) AS prev_month_revenue,
    ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month))
          / NULLIF(LAG(revenue) OVER (ORDER BY month), 0), 2) AS mom_growth_pct
FROM monthly
ORDER BY month;


-- =====================================================
-- Q3. Product categories generating the highest revenue
-- Skills: multi-table JOIN, GROUP BY, aggregate
-- =====================================================
SELECT
    COALESCE(t.product_category_name_english, p.product_category_name, 'unknown') AS category,
    COUNT(*)                         AS items_sold,
    ROUND(SUM(oi.price), 2)          AS revenue,
    ROUND(100.0 * SUM(oi.price) / SUM(SUM(oi.price)) OVER (), 2) AS pct_of_total
FROM order_items oi
JOIN orders o   ON o.order_id = oi.order_id
JOIN products p ON p.product_id = oi.product_id
LEFT JOIN product_category_translation t ON t.product_category_name = p.product_category_name
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY 1
ORDER BY revenue DESC
LIMIT 10;


-- =====================================================
-- Q4. Products with the highest sales volume
-- =====================================================
SELECT
    oi.product_id,
    COALESCE(t.product_category_name_english, 'unknown') AS category,
    COUNT(*)                AS units_sold,
    ROUND(SUM(oi.price), 2) AS revenue
FROM order_items oi
JOIN orders o   ON o.order_id = oi.order_id
JOIN products p ON p.product_id = oi.product_id
LEFT JOIN product_category_translation t ON t.product_category_name = p.product_category_name
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY oi.product_id, 2
ORDER BY units_sold DESC
LIMIT 10;


-- =====================================================
-- Q5. Sellers generating the highest revenue
-- Skills: HAVING, RANK window function
-- =====================================================
SELECT
    RANK() OVER (ORDER BY SUM(oi.price) DESC) AS revenue_rank,
    s.seller_id,
    s.seller_city,
    s.seller_state,
    COUNT(DISTINCT oi.order_id) AS orders,
    ROUND(SUM(oi.price), 2)     AS revenue
FROM order_items oi
JOIN orders  o ON o.order_id  = oi.order_id
JOIN sellers s ON s.seller_id = oi.seller_id
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY s.seller_id, s.seller_city, s.seller_state
HAVING SUM(oi.price) > 0
ORDER BY revenue DESC
LIMIT 10;


-- =====================================================
-- Q6a. States contributing the most sales (by customer state)
-- =====================================================
SELECT
    c.customer_state,
    COUNT(DISTINCT o.order_id) AS orders,
    ROUND(SUM(oi.price), 2)    AS revenue,
    ROUND(100.0 * SUM(oi.price) / SUM(SUM(oi.price)) OVER (), 2) AS pct_of_total
FROM orders o
JOIN customers   c  ON c.customer_id = o.customer_id
JOIN order_items oi ON oi.order_id   = o.order_id
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY c.customer_state
ORDER BY revenue DESC;

-- Q6b. Top 10 cities
SELECT
    c.customer_city,
    c.customer_state,
    COUNT(DISTINCT o.order_id) AS orders,
    ROUND(SUM(oi.price), 2)    AS revenue
FROM orders o
JOIN customers   c  ON c.customer_id = o.customer_id
JOIN order_items oi ON oi.order_id   = o.order_id
WHERE o.order_status NOT IN ('canceled', 'unavailable')
GROUP BY c.customer_city, c.customer_state
ORDER BY revenue DESC
LIMIT 10;


-- =====================================================
-- Q7. Average order value (AOV)
-- Skills: subquery
-- =====================================================
SELECT ROUND(AVG(order_value), 2) AS avg_order_value
FROM (
    SELECT oi.order_id, SUM(oi.price) AS order_value
    FROM order_items oi
    JOIN orders o ON o.order_id = oi.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY oi.order_id
) AS order_totals;


-- =====================================================
-- Q8. Most commonly used payment methods
-- =====================================================
SELECT
    payment_type,
    COUNT(DISTINCT order_id)    AS orders,
    ROUND(SUM(payment_value), 2) AS total_paid,
    ROUND(100.0 * COUNT(DISTINCT order_id)
          / (SELECT COUNT(DISTINCT order_id) FROM order_payments), 2) AS pct_of_orders
FROM order_payments
GROUP BY payment_type
ORDER BY orders DESC;


-- =====================================================
-- Q9. Average delivery time (days)
-- Skills: date functions, CASE
-- =====================================================
SELECT
    ROUND(AVG(EXTRACT(EPOCH FROM (order_delivered_customer_date - order_purchase_timestamp)) / 86400)::numeric, 2)
        AS avg_delivery_days,
    ROUND(AVG(EXTRACT(EPOCH FROM (order_estimated_delivery_date - order_purchase_timestamp)) / 86400)::numeric, 2)
        AS avg_estimated_days,
    ROUND(100.0 * AVG(CASE WHEN order_delivered_customer_date > order_estimated_delivery_date
                           THEN 1 ELSE 0 END), 2) AS pct_late
FROM orders
WHERE order_status = 'delivered'
  AND order_delivered_customer_date IS NOT NULL;

-- Q9b. Average delivery time by customer state
SELECT
    c.customer_state,
    COUNT(*) AS delivered_orders,
    ROUND(AVG(EXTRACT(EPOCH FROM (o.order_delivered_customer_date - o.order_purchase_timestamp)) / 86400)::numeric, 2)
        AS avg_delivery_days
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
WHERE o.order_status = 'delivered' AND o.order_delivered_customer_date IS NOT NULL
GROUP BY c.customer_state
HAVING COUNT(*) >= 100
ORDER BY avg_delivery_days DESC;


-- =====================================================
-- Q10. Categories with the highest customer ratings
-- Skills: CTE, HAVING (min. volume filter)
-- Note: reviews are averaged per order first to avoid duplicate-review bias.
-- =====================================================
WITH order_rating AS (
    SELECT order_id, AVG(review_score) AS score
    FROM order_reviews
    GROUP BY order_id
)
SELECT
    COALESCE(t.product_category_name_english, 'unknown') AS category,
    COUNT(DISTINCT oi.order_id)   AS reviewed_orders,
    ROUND(AVG(r.score), 2)        AS avg_rating
FROM order_items oi
JOIN order_rating r ON r.order_id = oi.order_id
JOIN products p     ON p.product_id = oi.product_id
LEFT JOIN product_category_translation t ON t.product_category_name = p.product_category_name
GROUP BY 1
HAVING COUNT(DISTINCT oi.order_id) >= 100
ORDER BY avg_rating DESC
LIMIT 10;


-- =====================================================
-- Q11. Are late deliveries associated with lower review scores?
-- Skills: CASE, CTE, JOIN
-- =====================================================
WITH order_rating AS (
    SELECT order_id, AVG(review_score) AS score
    FROM order_reviews
    GROUP BY order_id
)
SELECT
    CASE
        WHEN o.order_delivered_customer_date <= o.order_estimated_delivery_date THEN 'On time'
        ELSE 'Late'
    END                         AS delivery_status,
    COUNT(*)                    AS orders,
    ROUND(AVG(r.score), 2)      AS avg_review_score,
    ROUND(100.0 * AVG(CASE WHEN r.score <= 2 THEN 1 ELSE 0 END), 2) AS pct_bad_reviews
FROM orders o
JOIN order_rating r ON r.order_id = o.order_id
WHERE o.order_status = 'delivered'
  AND o.order_delivered_customer_date IS NOT NULL
GROUP BY 1
ORDER BY 1;


-- =====================================================
-- Q12. Top customers by spending
-- Skills: DENSE_RANK window function (customer_unique_id = the real person)
-- =====================================================
SELECT *
FROM (
    SELECT
        c.customer_unique_id,
        c.customer_state,
        COUNT(DISTINCT o.order_id)                AS orders,
        ROUND(SUM(oi.price + oi.freight_value), 2) AS total_spent,
        DENSE_RANK() OVER (ORDER BY SUM(oi.price + oi.freight_value) DESC) AS spend_rank
    FROM customers c
    JOIN orders o       ON o.customer_id = c.customer_id
    JOIN order_items oi ON oi.order_id   = o.order_id
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY c.customer_unique_id, c.customer_state
) ranked
WHERE spend_rank <= 10
ORDER BY spend_rank;


-- =====================================================
-- Q13. Percentage of orders cancelled
-- Skills: CASE, aggregate
-- =====================================================
SELECT
    COUNT(*)                                                     AS total_orders,
    SUM(CASE WHEN order_status = 'canceled' THEN 1 ELSE 0 END)   AS canceled_orders,
    ROUND(100.0 * SUM(CASE WHEN order_status = 'canceled' THEN 1 ELSE 0 END) / COUNT(*), 2)
                                                                 AS canceled_pct
FROM orders;

-- Q13b. Order status breakdown
SELECT order_status, COUNT(*) AS orders,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM orders
GROUP BY order_status
ORDER BY orders DESC;


-- =====================================================
-- Q14. Categories with high sales but poor customer ratings
-- Skills: CTE, subquery, HAVING, CASE
-- Logic: revenue above the median-ish category (above average) AND
--        avg rating below the overall platform average.
-- =====================================================
WITH order_rating AS (
    SELECT order_id, AVG(review_score) AS score
    FROM order_reviews
    GROUP BY order_id
),
category_stats AS (
    SELECT
        COALESCE(t.product_category_name_english, 'unknown') AS category,
        SUM(oi.price)               AS revenue,
        COUNT(DISTINCT oi.order_id) AS orders,
        AVG(r.score)                AS avg_rating
    FROM order_items oi
    JOIN orders o       ON o.order_id = oi.order_id
    JOIN order_rating r ON r.order_id = oi.order_id
    JOIN products p     ON p.product_id = oi.product_id
    LEFT JOIN product_category_translation t ON t.product_category_name = p.product_category_name
    WHERE o.order_status NOT IN ('canceled', 'unavailable')
    GROUP BY 1
    HAVING COUNT(DISTINCT oi.order_id) >= 100
)
SELECT
    category,
    ROUND(revenue, 2)    AS revenue,
    orders,
    ROUND(avg_rating, 2) AS avg_rating,
    CASE WHEN avg_rating < 3.8 THEN 'Critical' ELSE 'Watch' END AS priority
FROM category_stats
WHERE revenue    > (SELECT AVG(revenue)    FROM category_stats)
  AND avg_rating < (SELECT AVG(score)      FROM order_rating)
ORDER BY revenue DESC;


-- =====================================================
-- BONUS: additional CTE / window / ranking examples
-- =====================================================

-- B1. Top 3 products in each of the top 5 categories (ROW_NUMBER, PARTITION BY)
WITH product_sales AS (
    SELECT
        COALESCE(t.product_category_name_english, 'unknown') AS category,
        oi.product_id,
        SUM(oi.price) AS revenue
    FROM order_items oi
    JOIN products p ON p.product_id = oi.product_id
    LEFT JOIN product_category_translation t ON t.product_category_name = p.product_category_name
    GROUP BY 1, 2
),
top_categories AS (
    SELECT category FROM product_sales GROUP BY category ORDER BY SUM(revenue) DESC LIMIT 5
),
ranked AS (
    SELECT ps.*, ROW_NUMBER() OVER (PARTITION BY ps.category ORDER BY ps.revenue DESC) AS rn
    FROM product_sales ps
    JOIN top_categories tc ON tc.category = ps.category
)
SELECT category, product_id, ROUND(revenue, 2) AS revenue, rn AS rank_in_category
FROM ranked
WHERE rn <= 3
ORDER BY category, rn;

-- B2. Running (cumulative) revenue by month
WITH monthly AS (
    SELECT DATE_TRUNC('month', o.order_purchase_timestamp)::date AS month, SUM(oi.price) AS revenue
    FROM orders o JOIN order_items oi ON oi.order_id = o.order_id
    WHERE o.order_status NOT IN ('canceled','unavailable')
    GROUP BY 1
)
SELECT month, ROUND(revenue, 2) AS revenue,
       ROUND(SUM(revenue) OVER (ORDER BY month), 2) AS cumulative_revenue
FROM monthly ORDER BY month;

-- B3. Repeat vs. one-time customers
WITH cust_orders AS (
    SELECT c.customer_unique_id, COUNT(DISTINCT o.order_id) AS n_orders
    FROM customers c JOIN orders o ON o.customer_id = c.customer_id
    WHERE o.order_status NOT IN ('canceled','unavailable')
    GROUP BY 1
)
SELECT CASE WHEN n_orders = 1 THEN 'One-time' ELSE 'Repeat' END AS customer_type,
       COUNT(*) AS customers,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM cust_orders GROUP BY 1;

-- B4. Seller performance: revenue, avg rating, late-delivery rate
WITH order_rating AS (
    SELECT order_id, AVG(review_score) AS score FROM order_reviews GROUP BY order_id
)
SELECT s.seller_id, s.seller_state,
       COUNT(DISTINCT oi.order_id)                    AS orders,
       ROUND(SUM(oi.price), 2)                        AS revenue,
       ROUND(AVG(r.score), 2)                         AS avg_rating,
       ROUND(100.0 * AVG(CASE WHEN o.order_delivered_customer_date > o.order_estimated_delivery_date
                              THEN 1 ELSE 0 END), 2)  AS pct_late
FROM order_items oi
JOIN orders o  ON o.order_id = oi.order_id
JOIN sellers s ON s.seller_id = oi.seller_id
LEFT JOIN order_rating r ON r.order_id = oi.order_id
WHERE o.order_status = 'delivered'
GROUP BY s.seller_id, s.seller_state
HAVING COUNT(DISTINCT oi.order_id) >= 50
ORDER BY revenue DESC
LIMIT 15;
