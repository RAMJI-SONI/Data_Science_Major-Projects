# E-Commerce Sales & Customer Analytics (Olist, Brazil)

An end-to-end SQL analysis of the Brazilian Olist marketplace covering sales, customers, products, sellers, payments, delivery and customer satisfaction.

---

## 1. Business Problem

An e-commerce company wants to understand:

- Sales performance
- Customer behaviour
- Product performance
- Seller performance
- Delivery operations

The goal is to turn raw transactional data into insights that help the business grow revenue, retain customers and improve delivery and seller quality.

---

## 2. Dataset

**Brazilian E-Commerce Public Dataset by Olist** (~100k orders placed between 2016 and 2018 across multiple Brazilian marketplaces).

Source: <https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce>

| CSV file | Table | Description |
|---|---|---|
| olist_orders_dataset | `orders` | Order status and timestamps |
| olist_order_items_dataset | `order_items` | Items per order, price, freight, seller |
| olist_order_payments_dataset | `order_payments` | Payment type, installments, value |
| olist_order_reviews_dataset | `order_reviews` | Review score and comments |
| olist_customers_dataset | `customers` | Customer location and unique id |
| olist_sellers_dataset | `sellers` | Seller location |
| olist_products_dataset | `products` | Product category and dimensions |
| product_category_name_translation | `product_category_translation` | Portuguese → English category names |
| olist_geolocation_dataset | `geolocation` | Zip code coordinates |

---

## 3. Database Schema

PostgreSQL 13+. Full DDL in [`01_schema.sql`](01_schema.sql).

```
customers (customer_id PK, customer_unique_id, zip, city, state)
    └──< orders (order_id PK, customer_id FK, status, purchase/approved/delivered/estimated timestamps)
            ├──< order_items (order_id, order_item_id PK, product_id FK, seller_id FK, price, freight_value)
            ├──< order_payments (order_id, payment_sequential PK, payment_type, installments, payment_value)
            └──< order_reviews (review_id, order_id FK, review_score, comments, dates)
products (product_id PK, product_category_name, dimensions...) ──< order_items
sellers  (seller_id PK, zip, city, state)                       ──< order_items
product_category_translation (category_pt PK, category_en)
geolocation (zip_prefix, lat, lng, city, state)
```

### Setup instructions

```bash
# 1. Download and unzip the dataset from Kaggle into a folder, e.g. ~/olist_csv/
# 2. Create the database and tables
createdb olist
psql -d olist -f 01_schema.sql

# 3. Edit the `dir` path on the first line of 02_import.sql, then load the data
psql -d olist -f 02_import.sql

# 4. Run the analysis
psql -d olist -f 03_analysis_queries.sql
```

The import script ends with a row-count sanity check (about 99,441 orders and 112,650 order items).

### Metric definitions

| Metric | Definition |
|---|---|
| Revenue | `SUM(order_items.price)` (excludes freight) |
| Valid orders | `order_status NOT IN ('canceled','unavailable')` |
| Delivery time | `order_delivered_customer_date − order_purchase_timestamp`, delivered orders only |
| Late delivery | delivered date later than estimated delivery date |
| Customer | `customer_unique_id` (`customer_id` is generated per order) |
| Rating per order | average of `review_score` per order (some orders have several reviews) |

---

## 4. Business Questions

1. What is the total number of orders and total revenue?
2. What are the monthly and yearly sales trends?
3. Which product categories generate the highest revenue?
4. Which products have the highest sales volume?
5. Which sellers generate the highest revenue?
6. Which states/cities contribute the most sales?
7. What is the average order value?
8. Which payment methods are most commonly used?
9. What is the average delivery time?
10. Which categories have the highest customer ratings?
11. Are late deliveries associated with lower review scores?
12. Who are the top customers based on spending?
13. What percentage of orders are cancelled?
14. Which categories have high sales but poor customer ratings?

---

## 5. SQL Concepts Used

| Concept | Where used |
|---|---|
| `JOIN` (INNER / LEFT, multi-table) | All queries |
| `GROUP BY` | Q1–Q14 |
| `HAVING` | Q5, Q9b, Q10, Q14 (minimum-volume filters) |
| Aggregate functions (`SUM`, `COUNT`, `AVG`) | All queries |
| `CASE` | Q9, Q11, Q13, Q14, B3 |
| Date functions (`DATE_TRUNC`, `EXTRACT`) | Q2, Q9, B2 |
| Subqueries | Q7, Q8, Q12, Q14 |
| CTEs | Q2c, Q10, Q11, Q14, B1–B4 |
| Window functions (`LAG`, `SUM() OVER`) | Q2c, Q3, Q6a, Q13b, B2 |
| Ranking (`RANK`, `DENSE_RANK`, `ROW_NUMBER`) | Q5, Q12, B1 |

---

## 6. SQL Queries

All queries live in [`03_analysis_queries.sql`](03_analysis_queries.sql), numbered to match the business questions.

| # | Question | Technique |
|---|---|---|
| Q1 | Total orders & revenue | Aggregates, JOIN |
| Q2 | Monthly / yearly trend, MoM growth | `DATE_TRUNC`, `LAG` |
| Q3 | Top categories by revenue | JOIN, `SUM() OVER` for share |
| Q4 | Top products by volume | GROUP BY |
| Q5 | Top sellers | `RANK`, HAVING |
| Q6 | Top states / cities | GROUP BY, window share |
| Q7 | Average order value | Subquery |
| Q8 | Payment methods | Subquery for % |
| Q9 | Average delivery time | `EXTRACT(EPOCH …)`, CASE |
| Q10 | Best-rated categories | CTE, HAVING |
| Q11 | Late delivery vs review score | CASE, CTE |
| Q12 | Top customers | `DENSE_RANK` |
| Q13 | Cancellation rate | CASE |
| Q14 | High sales, poor ratings | CTE + subqueries |
| B1–B4 | Top products per category, cumulative revenue, repeat customers, seller scorecard | Window functions, CTEs |

Example (Q11, late delivery vs. satisfaction):

```sql
WITH order_rating AS (
    SELECT order_id, AVG(review_score) AS score
    FROM order_reviews GROUP BY order_id
)
SELECT
    CASE WHEN o.order_delivered_customer_date <= o.order_estimated_delivery_date
         THEN 'On time' ELSE 'Late' END AS delivery_status,
    COUNT(*) AS orders,
    ROUND(AVG(r.score), 2) AS avg_review_score
FROM orders o
JOIN order_rating r ON r.order_id = o.order_id
WHERE o.order_status = 'delivered' AND o.order_delivered_customer_date IS NOT NULL
GROUP BY 1;
```

---

## 7. Key Findings

> **Fill in from your own query output.** The figures below are the approximate values this dataset is commonly reported to produce; replace them with the exact numbers from your run and attach screenshots or result tables.

| Question | Finding (approx., verify) | Your result |
|---|---|---|
| Q1 Orders & revenue | ~99.4k orders; ~R$13.5M product revenue (~R$16M incl. freight) | |
| Q2 Trend | Strong growth through 2017 into 2018; Nov 2017 (Black Friday) is the peak month; data thins out after Aug 2018 | |
| Q3 Top categories | health_beauty, watches_gifts, bed_bath_table, sports_leisure, computers_accessories | |
| Q4 Top product volume | Household/bed-bath items dominate unit sales | |
| Q5 Top sellers | Revenue is concentrated in a small share of sellers | |
| Q6 Geography | São Paulo state ≈ 35–40% of revenue; then RJ and MG | |
| Q7 AOV | ~R$135–140 per order | |
| Q8 Payments | Credit card ≈ 74%, boleto ≈ 19%, then voucher and debit card | |
| Q9 Delivery | ~12 days average, ~8% of delivered orders arrive late | |
| Q10 Best-rated categories | Books, CDs/DVDs and some niche categories rate highest (avg ≈ 4.3+) | |
| Q11 Late vs rating | Late orders score far lower (≈ 2.5 vs ≈ 4.2 on time) | |
| Q12 Top customers | Spend is spread out; most customers order only once | |
| Q13 Cancellations | ~0.6% of orders cancelled | |
| Q14 High sales, low rating | Large categories with below-average ratings (e.g. bed/bath, furniture, computers) | |

---

## 8. Business Recommendations

1. **Fix delivery reliability first.** Late deliveries are strongly tied to 1–2 star reviews. Set more realistic delivery estimates, especially for remote states, and flag sellers with high late rates (query B4).
2. **Reduce geographic concentration.** Most revenue comes from the Southeast. Invest in logistics partners and local sellers in the North and Northeast, where delivery is slowest.
3. **Improve high-revenue, low-rating categories** (Q14). Work with sellers on product descriptions, packaging and quality control before scaling marketing.
4. **Build retention.** The large majority of customers buy once (B3). Launch post-purchase email flows, loyalty offers and category cross-sell.
5. **Prepare for seasonality.** Plan inventory, seller capacity and carrier agreements ahead of Black Friday and year-end peaks.
6. **Support payment preferences.** Credit card with installments is dominant; promote installment offers and keep boleto as an alternative for unbanked customers.
7. **Manage seller concentration risk.** Support top sellers with account management and coach underperforming sellers with high volume but poor ratings.

---

## Repository Structure

```
olist_project/
├── README.md
├── 01_schema.sql            # database/schema setup
├── 02_import.sql            # CSV import instructions + sanity checks
└── 03_analysis_queries.sql  # all analysis queries (Q1–Q14 + bonus)
```

## Tools

PostgreSQL 13+, psql (or DBeaver / pgAdmin).
