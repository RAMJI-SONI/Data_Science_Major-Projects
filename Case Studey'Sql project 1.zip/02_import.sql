-- =====================================================
-- Import the Kaggle CSVs (run with psql, uses \copy)
-- 1. Download & unzip: https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce
-- 2. Edit the folder path below (keep the trailing slash)
-- 3. Run: psql -d olist -f 02_import.sql
-- Order matters because of foreign keys.
-- =====================================================
\set dir '/path/to/olist_csv/'

\copy customers FROM :'dir'olist_customers_dataset.csv CSV HEADER
\copy sellers   FROM :'dir'olist_sellers_dataset.csv CSV HEADER
\copy product_category_translation FROM :'dir'product_category_name_translation.csv CSV HEADER
\copy products  FROM :'dir'olist_products_dataset.csv CSV HEADER
\copy orders    FROM :'dir'olist_orders_dataset.csv CSV HEADER
\copy order_items    FROM :'dir'olist_order_items_dataset.csv CSV HEADER
\copy order_payments FROM :'dir'olist_order_payments_dataset.csv CSV HEADER
\copy geolocation    FROM :'dir'olist_geolocation_dataset.csv CSV HEADER

-- Reviews contain duplicated review_ids and multi-line comments; CSV mode handles quotes
\copy order_reviews FROM :'dir'olist_order_reviews_dataset.csv CSV HEADER

-- Some products have categories missing from the translation table (e.g. pc_gamer,
-- portateis_cozinha_e_preparadores_de_alimentos). Add them so joins don't drop rows.
INSERT INTO product_category_translation VALUES
  ('pc_gamer','pc_gamer'),
  ('portateis_cozinha_e_preparadores_de_alimentos','portable_kitchen_food_preparers')
ON CONFLICT DO NOTHING;

-- Sanity check (expected approx.: 99441 orders, 112650 items, 32951 products, 3095 sellers)
SELECT 'customers' t, COUNT(*) FROM customers UNION ALL
SELECT 'orders', COUNT(*) FROM orders UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items UNION ALL
SELECT 'products', COUNT(*) FROM products UNION ALL
SELECT 'sellers', COUNT(*) FROM sellers UNION ALL
SELECT 'order_payments', COUNT(*) FROM order_payments UNION ALL
SELECT 'order_reviews', COUNT(*) FROM order_reviews;
