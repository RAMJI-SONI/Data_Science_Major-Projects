-- =====================================================================
-- PROJECT 02: Retail Sales & Product Performance Analysis
-- Database setup + verification (Microsoft SQL Server / T-SQL)
-- =====================================================================
-- AdventureWorks is distributed as a backup (.bak), not as CSV files.
-- Step 1 (once): download AdventureWorks2022.bak (the OLTP version, NOT the DW or LT one) from
--   https://learn.microsoft.com/en-us/sql/samples/adventureworks-install-configure
-- Step 2: restore it using ONE of these ways:
--   a) SSMS: right-click Databases > Restore Database > Device > pick the .bak > OK
--   b) Run the T-SQL below (edit the paths first, then uncomment):
--
-- RESTORE DATABASE AdventureWorks2022
-- FROM DISK = N'C:\Backup\AdventureWorks2022.bak'
-- WITH MOVE N'AdventureWorks2022'     TO N'C:\SQLData\AdventureWorks2022.mdf',
--      MOVE N'AdventureWorks2022_log' TO N'C:\SQLData\AdventureWorks2022_log.ldf',
--      REPLACE, STATS = 10;
--
-- (If a different version is used, check the logical names first with:
--  RESTORE FILELISTONLY FROM DISK = N'C:\Backup\AdventureWorks2022.bak';)
--
-- Step 3: run the verification below. If your database has another name
-- (e.g. AdventureWorks2019), change the USE line here AND in 02_analysis_queries.sql.
-- =====================================================================

USE AdventureWorks2022;

-- Verification: expected row counts for the standard AdventureWorks OLTP sample
SELECT 'Sales.SalesOrderHeader' AS table_name, COUNT(*) AS row_count FROM Sales.SalesOrderHeader   -- 31465
UNION ALL SELECT 'Sales.SalesOrderDetail',  COUNT(*) FROM Sales.SalesOrderDetail                   -- 121317
UNION ALL SELECT 'Sales.Customer',          COUNT(*) FROM Sales.Customer                           -- 19820
UNION ALL SELECT 'Sales.SalesTerritory',    COUNT(*) FROM Sales.SalesTerritory                     -- 10
UNION ALL SELECT 'Sales.SalesPerson',       COUNT(*) FROM Sales.SalesPerson                        -- 17
UNION ALL SELECT 'Production.Product',      COUNT(*) FROM Production.Product                       -- 504
UNION ALL SELECT 'Production.ProductSubcategory', COUNT(*) FROM Production.ProductSubcategory     -- 37
UNION ALL SELECT 'Production.ProductCategory',    COUNT(*) FROM Production.ProductCategory;       -- 4

-- Date coverage of the sales data (orders run from 2011-05-31 to 2014-06-30)
SELECT MIN(OrderDate) AS first_order_date, MAX(OrderDate) AS last_order_date
FROM Sales.SalesOrderHeader;
