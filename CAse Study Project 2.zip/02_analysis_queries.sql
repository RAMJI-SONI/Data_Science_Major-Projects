-- =====================================================================
-- PROJECT 02: Retail Sales & Product Performance Analysis
-- Analysis queries - Microsoft SQL Server (T-SQL), AdventureWorks OLTP
-- =====================================================================
-- Definitions
--   Revenue (order level)   = SUM(Sales.SalesOrderHeader.SubTotal)  (before tax and freight)
--   Revenue (product level) = SUM(Sales.SalesOrderDetail.LineTotal)  (same total as SubTotal)
--   Data coverage           = 2011-05-31 to 2014-06-30, so 2011 and 2014 are PARTIAL years.
--   Customer                = row in Sales.Customer (Store = reseller, otherwise individual)
-- Run each query separately (highlight and execute) or run the whole file.
-- =====================================================================

USE AdventureWorks2022;   -- change if your database has a different name


-- =====================================================================
-- Q1. What is the total sales revenue?
-- Skills: aggregate functions
-- =====================================================================
SELECT
    COUNT(*)                                   AS total_orders,
    COUNT(DISTINCT CustomerID)                 AS customers_with_orders,
    CAST(SUM(SubTotal) AS DECIMAL(18,2))       AS total_sales_revenue,
    CAST(SUM(TotalDue) AS DECIMAL(18,2))       AS total_revenue_incl_tax_freight
FROM Sales.SalesOrderHeader;

-- Q1b. Cross-check: line-level revenue must equal the order-level SubTotal
SELECT CAST(SUM(LineTotal) AS DECIMAL(18,2)) AS total_line_revenue
FROM Sales.SalesOrderDetail;


-- =====================================================================
-- Q2. What are the yearly and monthly sales trends?
-- Skills: date functions, GROUP BY, window function LAG, CTE
-- =====================================================================
-- Q2a. Yearly trend with year-over-year growth (2011 and 2014 are partial years)
WITH yearly AS (
    SELECT
        YEAR(OrderDate)  AS order_year,
        COUNT(*)         AS orders,
        SUM(SubTotal)    AS revenue
    FROM Sales.SalesOrderHeader
    GROUP BY YEAR(OrderDate)
)
SELECT
    order_year,
    orders,
    CAST(revenue AS DECIMAL(18,2)) AS revenue,
    CAST(100.0 * (revenue - LAG(revenue) OVER (ORDER BY order_year))
         / NULLIF(LAG(revenue) OVER (ORDER BY order_year), 0) AS DECIMAL(10,2)) AS yoy_growth_pct
FROM yearly
ORDER BY order_year;

-- Q2b. Monthly trend with month-over-month growth
WITH monthly AS (
    SELECT
        DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1) AS month_start,
        COUNT(*)                                            AS orders,
        SUM(SubTotal)                                       AS revenue
    FROM Sales.SalesOrderHeader
    GROUP BY DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1)
)
SELECT
    month_start,
    orders,
    CAST(revenue AS DECIMAL(18,2)) AS revenue,
    CAST(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month_start))
         / NULLIF(LAG(revenue) OVER (ORDER BY month_start), 0) AS DECIMAL(10,2)) AS mom_growth_pct
FROM monthly
ORDER BY month_start;


-- =====================================================================
-- Q3. Which products generate the highest revenue?
-- Skills: JOIN, GROUP BY, window function for share of total
-- =====================================================================
SELECT TOP (10)
    p.ProductID,
    p.Name                                           AS product_name,
    SUM(sod.OrderQty)                                AS units_sold,
    CAST(SUM(sod.LineTotal) AS DECIMAL(18,2))        AS revenue,
    CAST(100.0 * SUM(sod.LineTotal) / SUM(SUM(sod.LineTotal)) OVER () AS DECIMAL(10,2)) AS pct_of_total_revenue
FROM Sales.SalesOrderDetail AS sod
JOIN Production.Product     AS p ON p.ProductID = sod.ProductID
GROUP BY p.ProductID, p.Name
ORDER BY SUM(sod.LineTotal) DESC;


-- =====================================================================
-- Q4. Which products have the highest sales quantity?
-- =====================================================================
SELECT TOP (10)
    p.ProductID,
    p.Name                                    AS product_name,
    SUM(sod.OrderQty)                         AS units_sold,
    CAST(SUM(sod.LineTotal) AS DECIMAL(18,2)) AS revenue
FROM Sales.SalesOrderDetail AS sod
JOIN Production.Product     AS p ON p.ProductID = sod.ProductID
GROUP BY p.ProductID, p.Name
ORDER BY SUM(sod.OrderQty) DESC;


-- =====================================================================
-- Q5. Which product categories perform best?
-- Skills: multi-table JOIN, GROUP BY, HAVING, window function
-- =====================================================================
SELECT
    pc.Name                                   AS category,
    COUNT(DISTINCT p.ProductID)               AS products_sold,
    SUM(sod.OrderQty)                         AS units_sold,
    CAST(SUM(sod.LineTotal) AS DECIMAL(18,2)) AS revenue,
    CAST(100.0 * SUM(sod.LineTotal) / SUM(SUM(sod.LineTotal)) OVER () AS DECIMAL(10,2)) AS pct_of_total_revenue
FROM Sales.SalesOrderDetail       AS sod
JOIN Production.Product           AS p   ON p.ProductID = sod.ProductID
JOIN Production.ProductSubcategory AS psc ON psc.ProductSubcategoryID = p.ProductSubcategoryID
JOIN Production.ProductCategory   AS pc  ON pc.ProductCategoryID = psc.ProductCategoryID
GROUP BY pc.Name
HAVING SUM(sod.LineTotal) > 0
ORDER BY SUM(sod.LineTotal) DESC;

-- Q5b. Best subcategories (top 10)
SELECT TOP (10)
    pc.Name                                   AS category,
    psc.Name                                  AS subcategory,
    SUM(sod.OrderQty)                         AS units_sold,
    CAST(SUM(sod.LineTotal) AS DECIMAL(18,2)) AS revenue
FROM Sales.SalesOrderDetail       AS sod
JOIN Production.Product           AS p   ON p.ProductID = sod.ProductID
JOIN Production.ProductSubcategory AS psc ON psc.ProductSubcategoryID = p.ProductSubcategoryID
JOIN Production.ProductCategory   AS pc  ON pc.ProductCategoryID = psc.ProductCategoryID
GROUP BY pc.Name, psc.Name
ORDER BY SUM(sod.LineTotal) DESC;


-- =====================================================================
-- Q6. Who are the top customers?
-- Skills: CTE, RANK, CASE, LEFT JOIN
-- Store customers (resellers) are named after the store; others after the person.
-- =====================================================================
WITH customer_sales AS (
    SELECT
        c.CustomerID,
        CASE WHEN c.StoreID IS NOT NULL THEN st.Name
             ELSE p.FirstName + N' ' + p.LastName END     AS customer_name,
        CASE WHEN c.StoreID IS NOT NULL THEN 'Store (reseller)'
             ELSE 'Individual' END                        AS customer_type,
        COUNT(*)                                          AS orders,
        SUM(soh.SubTotal)                                 AS total_spent
    FROM Sales.SalesOrderHeader AS soh
    JOIN Sales.Customer         AS c  ON c.CustomerID = soh.CustomerID
    LEFT JOIN Person.Person     AS p  ON p.BusinessEntityID = c.PersonID
    LEFT JOIN Sales.Store       AS st ON st.BusinessEntityID = c.StoreID
    GROUP BY c.CustomerID, c.StoreID, st.Name, p.FirstName, p.LastName
),
ranked AS (
    SELECT *, RANK() OVER (ORDER BY total_spent DESC) AS spend_rank
    FROM customer_sales
)
SELECT
    spend_rank,
    CustomerID,
    customer_name,
    customer_type,
    orders,
    CAST(total_spent AS DECIMAL(18,2)) AS total_spent
FROM ranked
WHERE spend_rank <= 10
ORDER BY spend_rank;


-- =====================================================================
-- Q7. Which sales territories generate the most revenue?
-- =====================================================================
SELECT
    st.TerritoryID,
    st.Name                                   AS territory,
    st.[Group]                                AS sales_group,
    st.CountryRegionCode                      AS country_code,
    COUNT(*)                                  AS orders,
    CAST(SUM(soh.SubTotal) AS DECIMAL(18,2))  AS revenue,
    CAST(100.0 * SUM(soh.SubTotal) / SUM(SUM(soh.SubTotal)) OVER () AS DECIMAL(10,2)) AS pct_of_total_revenue,
    RANK() OVER (ORDER BY SUM(soh.SubTotal) DESC) AS revenue_rank
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesTerritory   AS st ON st.TerritoryID = soh.TerritoryID
GROUP BY st.TerritoryID, st.Name, st.[Group], st.CountryRegionCode
ORDER BY revenue_rank;


-- =====================================================================
-- Q8. Which salespersons have the highest sales?
-- Skills: JOIN, RANK, CTE (only orders with a salesperson, i.e. reseller orders)
-- =====================================================================
WITH salesperson_sales AS (
    SELECT
        sp.BusinessEntityID                        AS salesperson_id,
        p.FirstName + N' ' + p.LastName            AS salesperson_name,
        terr.Name                                  AS territory,
        COUNT(*)                                   AS orders,
        SUM(soh.SubTotal)                          AS revenue
    FROM Sales.SalesOrderHeader AS soh
    JOIN Sales.SalesPerson      AS sp   ON sp.BusinessEntityID = soh.SalesPersonID
    JOIN Person.Person          AS p    ON p.BusinessEntityID = sp.BusinessEntityID
    LEFT JOIN Sales.SalesTerritory AS terr ON terr.TerritoryID = sp.TerritoryID
    GROUP BY sp.BusinessEntityID, p.FirstName, p.LastName, terr.Name
)
SELECT
    RANK() OVER (ORDER BY revenue DESC)       AS revenue_rank,
    salesperson_id,
    salesperson_name,
    territory,
    orders,
    CAST(revenue AS DECIMAL(18,2))            AS revenue,
    CAST(revenue / orders AS DECIMAL(18,2))   AS avg_order_value
FROM salesperson_sales
ORDER BY revenue_rank;


-- =====================================================================
-- Q9. What is the average order value?
-- Skills: aggregate, subquery, CASE
-- =====================================================================
SELECT
    CAST(AVG(order_value) AS DECIMAL(18,2)) AS avg_order_value
FROM (
    SELECT SalesOrderID, SubTotal AS order_value
    FROM Sales.SalesOrderHeader
) AS order_totals;

-- Q9b. Average order value by sales channel
SELECT
    CASE WHEN OnlineOrderFlag = 1 THEN 'Online' ELSE 'Reseller (store)' END AS channel,
    COUNT(*)                                  AS orders,
    CAST(SUM(SubTotal) AS DECIMAL(18,2))      AS revenue,
    CAST(AVG(SubTotal) AS DECIMAL(18,2))      AS avg_order_value
FROM Sales.SalesOrderHeader
GROUP BY CASE WHEN OnlineOrderFlag = 1 THEN 'Online' ELSE 'Reseller (store)' END
ORDER BY revenue DESC;


-- =====================================================================
-- Q10. Which products have declining sales?
-- Skills: CTE, CASE (conditional aggregation), HAVING, date functions
-- 2011 and 2014 are partial years, so compare full year 2012 vs 2013,
-- and the same half-year (Jan-Jun) of 2013 vs 2014.
-- =====================================================================
-- Q10a. Full-year revenue 2012 vs 2013
WITH product_year AS (
    SELECT
        p.ProductID,
        p.Name AS product_name,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2012 THEN sod.LineTotal ELSE 0 END) AS revenue_2012,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2013 THEN sod.LineTotal ELSE 0 END) AS revenue_2013
    FROM Sales.SalesOrderDetail AS sod
    JOIN Sales.SalesOrderHeader AS soh ON soh.SalesOrderID = sod.SalesOrderID
    JOIN Production.Product     AS p   ON p.ProductID = sod.ProductID
    GROUP BY p.ProductID, p.Name
    HAVING SUM(CASE WHEN YEAR(soh.OrderDate) = 2012 THEN sod.LineTotal ELSE 0 END) > 0
)
SELECT TOP (15)
    ProductID,
    product_name,
    CAST(revenue_2012 AS DECIMAL(18,2)) AS revenue_2012,
    CAST(revenue_2013 AS DECIMAL(18,2)) AS revenue_2013,
    CAST(revenue_2013 - revenue_2012 AS DECIMAL(18,2)) AS revenue_change,
    CAST(100.0 * (revenue_2013 - revenue_2012) / revenue_2012 AS DECIMAL(10,2)) AS change_pct
FROM product_year
WHERE revenue_2013 < revenue_2012
ORDER BY revenue_change ASC;

-- Q10b. Same half-year comparison: Jan-Jun 2013 vs Jan-Jun 2014
WITH product_h1 AS (
    SELECT
        p.ProductID,
        p.Name AS product_name,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2013 THEN sod.LineTotal ELSE 0 END) AS h1_2013,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2014 THEN sod.LineTotal ELSE 0 END) AS h1_2014
    FROM Sales.SalesOrderDetail AS sod
    JOIN Sales.SalesOrderHeader AS soh ON soh.SalesOrderID = sod.SalesOrderID
    JOIN Production.Product     AS p   ON p.ProductID = sod.ProductID
    WHERE MONTH(soh.OrderDate) <= 6
      AND YEAR(soh.OrderDate) IN (2013, 2014)
    GROUP BY p.ProductID, p.Name
    HAVING SUM(CASE WHEN YEAR(soh.OrderDate) = 2013 THEN sod.LineTotal ELSE 0 END) > 0
)
SELECT TOP (15)
    ProductID,
    product_name,
    CAST(h1_2013 AS DECIMAL(18,2)) AS revenue_h1_2013,
    CAST(h1_2014 AS DECIMAL(18,2)) AS revenue_h1_2014,
    CAST(h1_2014 - h1_2013 AS DECIMAL(18,2)) AS revenue_change,
    CAST(100.0 * (h1_2014 - h1_2013) / h1_2013 AS DECIMAL(10,2)) AS change_pct
FROM product_h1
WHERE h1_2014 < h1_2013
ORDER BY revenue_change ASC;


-- =====================================================================
-- Q11. What percentage of total revenue comes from the top 10 products?
-- Skills: CTE, TOP, subquery
-- =====================================================================
WITH product_revenue AS (
    SELECT ProductID, SUM(LineTotal) AS revenue
    FROM Sales.SalesOrderDetail
    GROUP BY ProductID
),
top10 AS (
    SELECT TOP (10) ProductID, revenue
    FROM product_revenue
    ORDER BY revenue DESC
)
SELECT
    CAST(SUM(t.revenue) AS DECIMAL(18,2))                                   AS top10_revenue,
    CAST((SELECT SUM(revenue) FROM product_revenue) AS DECIMAL(18,2))       AS total_revenue,
    CAST(100.0 * SUM(t.revenue) / (SELECT SUM(revenue) FROM product_revenue) AS DECIMAL(10,2)) AS top10_pct_of_revenue
FROM top10 AS t;


-- =====================================================================
-- Q12. What are the best-performing product categories by year?
-- Skills: CTE, RANK with PARTITION BY, date functions
-- =====================================================================
WITH category_year AS (
    SELECT
        YEAR(soh.OrderDate)  AS order_year,
        pc.Name              AS category,
        SUM(sod.LineTotal)   AS revenue,
        SUM(sod.OrderQty)    AS units_sold
    FROM Sales.SalesOrderDetail       AS sod
    JOIN Sales.SalesOrderHeader       AS soh ON soh.SalesOrderID = sod.SalesOrderID
    JOIN Production.Product           AS p   ON p.ProductID = sod.ProductID
    JOIN Production.ProductSubcategory AS psc ON psc.ProductSubcategoryID = p.ProductSubcategoryID
    JOIN Production.ProductCategory   AS pc  ON pc.ProductCategoryID = psc.ProductCategoryID
    GROUP BY YEAR(soh.OrderDate), pc.Name
)
SELECT
    order_year,
    category,
    CAST(revenue AS DECIMAL(18,2)) AS revenue,
    units_sold,
    RANK() OVER (PARTITION BY order_year ORDER BY revenue DESC) AS rank_in_year
FROM category_year
ORDER BY order_year, rank_in_year;


-- =====================================================================
-- Q13. Which customers have made multiple purchases?
-- Skills: HAVING, CASE, CTE
-- =====================================================================
-- Q13a. Customers with more than one order (top 20 by number of orders)
SELECT TOP (20)
    c.CustomerID,
    CASE WHEN c.StoreID IS NOT NULL THEN st.Name
         ELSE p.FirstName + N' ' + p.LastName END  AS customer_name,
    COUNT(*)                                       AS orders,
    CAST(SUM(soh.SubTotal) AS DECIMAL(18,2))       AS total_spent,
    MIN(soh.OrderDate)                             AS first_order,
    MAX(soh.OrderDate)                             AS last_order
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.Customer         AS c  ON c.CustomerID = soh.CustomerID
LEFT JOIN Person.Person     AS p  ON p.BusinessEntityID = c.PersonID
LEFT JOIN Sales.Store       AS st ON st.BusinessEntityID = c.StoreID
GROUP BY c.CustomerID, c.StoreID, st.Name, p.FirstName, p.LastName
HAVING COUNT(*) > 1
ORDER BY COUNT(*) DESC, SUM(soh.SubTotal) DESC;

-- Q13b. Repeat vs one-time customers
WITH customer_orders AS (
    SELECT CustomerID, COUNT(*) AS orders, SUM(SubTotal) AS revenue
    FROM Sales.SalesOrderHeader
    GROUP BY CustomerID
)
SELECT
    CASE WHEN orders = 1 THEN 'One-time customer' ELSE 'Repeat customer' END AS customer_type,
    COUNT(*)                                                                  AS customers,
    CAST(100.0 * COUNT(*) / SUM(COUNT(*)) OVER () AS DECIMAL(10,2))           AS pct_of_customers,
    CAST(SUM(revenue) AS DECIMAL(18,2))                                       AS revenue,
    CAST(100.0 * SUM(revenue) / SUM(SUM(revenue)) OVER () AS DECIMAL(10,2))   AS pct_of_revenue
FROM customer_orders
GROUP BY CASE WHEN orders = 1 THEN 'One-time customer' ELSE 'Repeat customer' END;


-- =====================================================================
-- Q14. How does sales performance vary across territories?
-- Skills: aggregates, window functions, CASE, CTE
-- =====================================================================
-- Q14a. Territory scorecard
SELECT
    st.Name                                                         AS territory,
    st.[Group]                                                      AS sales_group,
    COUNT(DISTINCT soh.CustomerID)                                  AS customers,
    COUNT(*)                                                        AS orders,
    CAST(SUM(soh.SubTotal) AS DECIMAL(18,2))                        AS revenue,
    CAST(AVG(soh.SubTotal) AS DECIMAL(18,2))                        AS avg_order_value,
    CAST(SUM(soh.SubTotal) / COUNT(DISTINCT soh.CustomerID) AS DECIMAL(18,2)) AS revenue_per_customer,
    CAST(100.0 * SUM(CASE WHEN soh.OnlineOrderFlag = 1 THEN 1 ELSE 0 END) / COUNT(*) AS DECIMAL(10,2)) AS pct_online_orders,
    RANK() OVER (ORDER BY SUM(soh.SubTotal) DESC)                   AS revenue_rank
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesTerritory   AS st ON st.TerritoryID = soh.TerritoryID
GROUP BY st.Name, st.[Group]
ORDER BY revenue_rank;

-- Q14b. Territory growth: full-year 2012 vs 2013
WITH territory_year AS (
    SELECT
        st.Name AS territory,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2012 THEN soh.SubTotal ELSE 0 END) AS revenue_2012,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2013 THEN soh.SubTotal ELSE 0 END) AS revenue_2013
    FROM Sales.SalesOrderHeader AS soh
    JOIN Sales.SalesTerritory   AS st ON st.TerritoryID = soh.TerritoryID
    GROUP BY st.Name
)
SELECT
    territory,
    CAST(revenue_2012 AS DECIMAL(18,2)) AS revenue_2012,
    CAST(revenue_2013 AS DECIMAL(18,2)) AS revenue_2013,
    CAST(100.0 * (revenue_2013 - revenue_2012) / NULLIF(revenue_2012, 0) AS DECIMAL(10,2)) AS growth_pct
FROM territory_year
ORDER BY growth_pct DESC;


-- =====================================================================
-- Q15. Which products have high quantity sold but relatively low revenue?
-- Skills: CTE, NTILE ranking, subquery-free quartile logic
-- Quartile 1 = highest. Flag products in the top quartile for units
-- whose revenue falls in the bottom half of all products.
-- =====================================================================
WITH product_stats AS (
    SELECT
        p.ProductID,
        p.Name                       AS product_name,
        SUM(sod.OrderQty)            AS units_sold,
        SUM(sod.LineTotal)           AS revenue
    FROM Sales.SalesOrderDetail AS sod
    JOIN Production.Product     AS p ON p.ProductID = sod.ProductID
    GROUP BY p.ProductID, p.Name
),
quartiles AS (
    SELECT
        ProductID,
        product_name,
        units_sold,
        revenue,
        NTILE(4) OVER (ORDER BY units_sold DESC) AS units_quartile,
        NTILE(4) OVER (ORDER BY revenue DESC)    AS revenue_quartile
    FROM product_stats
)
SELECT
    ProductID,
    product_name,
    units_sold,
    CAST(revenue AS DECIMAL(18,2))                          AS revenue,
    CAST(revenue / NULLIF(units_sold, 0) AS DECIMAL(18,2))  AS revenue_per_unit,
    units_quartile,
    revenue_quartile
FROM quartiles
WHERE units_quartile = 1
  AND revenue_quartile >= 3
ORDER BY units_sold DESC;


-- =====================================================================
-- BONUS queries
-- =====================================================================
-- B1. Top 3 products inside each product category (ROW_NUMBER + PARTITION BY)
WITH category_product AS (
    SELECT
        pc.Name            AS category,
        p.Name             AS product_name,
        SUM(sod.LineTotal) AS revenue
    FROM Sales.SalesOrderDetail       AS sod
    JOIN Production.Product           AS p   ON p.ProductID = sod.ProductID
    JOIN Production.ProductSubcategory AS psc ON psc.ProductSubcategoryID = p.ProductSubcategoryID
    JOIN Production.ProductCategory   AS pc  ON pc.ProductCategoryID = psc.ProductCategoryID
    GROUP BY pc.Name, p.Name
),
ranked AS (
    SELECT
        category,
        product_name,
        revenue,
        ROW_NUMBER() OVER (PARTITION BY category ORDER BY revenue DESC) AS rn
    FROM category_product
)
SELECT category, product_name, CAST(revenue AS DECIMAL(18,2)) AS revenue, rn AS rank_in_category
FROM ranked
WHERE rn <= 3
ORDER BY category, rn;

-- B2. Cumulative (running) revenue by month
WITH monthly AS (
    SELECT
        DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1) AS month_start,
        SUM(SubTotal)                                       AS revenue
    FROM Sales.SalesOrderHeader
    GROUP BY DATEFROMPARTS(YEAR(OrderDate), MONTH(OrderDate), 1)
)
SELECT
    month_start,
    CAST(revenue AS DECIMAL(18,2)) AS revenue,
    CAST(SUM(revenue) OVER (ORDER BY month_start ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS DECIMAL(18,2)) AS cumulative_revenue
FROM monthly
ORDER BY month_start;
