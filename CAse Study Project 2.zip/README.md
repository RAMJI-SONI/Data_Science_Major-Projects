# Retail Sales & Product Performance Analytics using SQL

An end-to-end SQL analysis of the Microsoft AdventureWorks sample database covering sales performance, customers, products, territories and salesperson performance.

---

## 1. Business Problem

A retail company (AdventureWorks Cycles, a bicycle and accessories manufacturer and seller) wants to understand:

- Sales performance
- Customers
- Products
- Territories
- Salesperson performance

The goal is to identify what drives revenue, which products and regions are growing or declining, and where the business should focus.

---

## 2. Dataset

**Microsoft AdventureWorks Sample Database** (OLTP version, SQL Server).

Install guide: <https://github.com/MicrosoftDocs/sql-docs/blob/live/docs/samples/adventureworks-install-configure.md>

- Sales orders cover **2011-05-31 to 2014-06-30**. **2011 and 2014 are partial years**, so year-over-year comparisons in this project use full years (2012 vs 2013) or the same half-year (Jan–Jun 2013 vs 2014).
- Two sales channels: **Online** (individual customers) and **Reseller** (stores served by salespersons).

---

## 3. Database Schema

SQL Server 2016+ (tested logic for T-SQL; AdventureWorks2019/2022 OLTP).

Tables used:

| Table | Purpose |
|---|---|
| `Sales.SalesOrderHeader` | One row per order: date, customer, territory, salesperson, `SubTotal`, `TotalDue`, online flag |
| `Sales.SalesOrderDetail` | One row per order line: product, `OrderQty`, `UnitPrice`, `LineTotal` |
| `Production.Product` | Product name, subcategory, prices |
| `Production.ProductSubcategory` / `Production.ProductCategory` | Product hierarchy (Bikes, Components, Clothing, Accessories) |
| `Sales.Customer` | Customer; `StoreID` set for resellers, `PersonID` for individuals |
| `Person.Person` / `Sales.Store` | Customer and salesperson names |
| `Sales.SalesTerritory` | Territory name, group, country |
| `Sales.SalesPerson` | Salespersons and their territory |

```
SalesTerritory ──< SalesOrderHeader >── Customer ── Person / Store
                        │  └── SalesPerson ── Person
                        └──< SalesOrderDetail >── Product ── ProductSubcategory ── ProductCategory
```

### Setup instructions

1. Download **AdventureWorks2022.bak** (the *OLTP* backup, not DW or LT) from the install guide above.
2. Restore it in SSMS / Azure Data Studio (*Databases → Restore Database → Device → select the .bak*), or use the `RESTORE DATABASE` template inside `01_database_setup.sql` after editing the file paths.
3. Run `01_database_setup.sql` to verify the row counts (e.g. 31,465 orders, 121,317 order lines).
4. Run `02_analysis_queries.sql`.

> If your database is named differently (e.g. `AdventureWorks2019`), change the `USE` line at the top of both SQL files.

### Metric definitions

| Metric | Definition |
|---|---|
| Revenue (order level) | `SUM(SalesOrderHeader.SubTotal)`, before tax and freight |
| Revenue (product level) | `SUM(SalesOrderDetail.LineTotal)` (same total as above) |
| Average order value | Average `SubTotal` per order |
| Repeat customer | Customer with more than one order |

---

## 4. Business Questions

1. What is the total sales revenue?
2. What are the yearly and monthly sales trends?
3. Which products generate the highest revenue?
4. Which products have the highest sales quantity?
5. Which product categories perform best?
6. Who are the top customers?
7. Which sales territories generate the most revenue?
8. Which salespersons have the highest sales?
9. What is the average order value?
10. Which products have declining sales?
11. What percentage of total revenue comes from the top 10 products?
12. What are the best-performing product categories by year?
13. Which customers have made multiple purchases?
14. How does sales performance vary across territories?
15. Which products have high quantity sold but relatively low revenue?

---

## 5. SQL Concepts Used

| Concept | Where used |
|---|---|
| `JOIN` (INNER, LEFT, multi-table) | All queries |
| `GROUP BY` | Q1–Q15 |
| `HAVING` | Q5, Q10, Q13 |
| Aggregate functions | All queries |
| `CASE` | Q6, Q9b, Q10, Q13, Q14 |
| Subqueries | Q9, Q11 |
| CTEs | Q2, Q6, Q8, Q10–Q15, B1, B2 |
| Window functions (`LAG`, `SUM() OVER`) | Q2, Q3, Q5, Q7, Q13b, B2 |
| Ranking (`RANK`, `ROW_NUMBER`, `NTILE`) | Q6, Q7, Q8, Q12, Q14, Q15, B1 |
| Date functions (`YEAR`, `MONTH`, `DATEFROMPARTS`) | Q2, Q10, Q12, Q14b, B2 |

---

## 6. SQL Queries

All queries are in [`02_analysis_queries.sql`](02_analysis_queries.sql), numbered to match the questions above (T-SQL syntax).

| # | Question | Technique |
|---|---|---|
| Q1 | Total revenue | Aggregates, cross-check against line totals |
| Q2 | Yearly / monthly trend, YoY and MoM growth | `LAG`, `DATEFROMPARTS` |
| Q3 | Top products by revenue | JOIN, share of total |
| Q4 | Top products by quantity | GROUP BY |
| Q5 | Best categories / subcategories | 4-table JOIN, HAVING |
| Q6 | Top customers | CTE, `RANK`, CASE |
| Q7 | Revenue by territory | `RANK`, window share |
| Q8 | Top salespersons | CTE, `RANK` |
| Q9 | Average order value (overall and by channel) | Subquery, CASE |
| Q10 | Declining products (2012→2013, H1 2013→H1 2014) | Conditional aggregation, HAVING |
| Q11 | Top-10 product revenue share | CTE, `TOP`, subquery |
| Q12 | Best categories by year | `RANK ... PARTITION BY` |
| Q13 | Repeat customers | HAVING, CASE |
| Q14 | Territory scorecard and growth | Window functions, CASE |
| Q15 | High quantity, low revenue products | `NTILE` |
| B1–B2 | Top 3 products per category, cumulative revenue | `ROW_NUMBER`, running total |

Example (Q10a, products with falling revenue):

```sql
WITH product_year AS (
    SELECT p.ProductID, p.Name AS product_name,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2012 THEN sod.LineTotal ELSE 0 END) AS revenue_2012,
        SUM(CASE WHEN YEAR(soh.OrderDate) = 2013 THEN sod.LineTotal ELSE 0 END) AS revenue_2013
    FROM Sales.SalesOrderDetail sod
    JOIN Sales.SalesOrderHeader soh ON soh.SalesOrderID = sod.SalesOrderID
    JOIN Production.Product p ON p.ProductID = sod.ProductID
    GROUP BY p.ProductID, p.Name
)
SELECT TOP (15) * FROM product_year
WHERE revenue_2012 > 0 AND revenue_2013 < revenue_2012
ORDER BY revenue_2013 - revenue_2012;
```

---

## 7. Key Findings

> **Complete from your own query output.** Figures marked "~" are the approximate values this sample database is commonly reported to produce; replace them with your exact results and add screenshots.

| Question | Finding (approx., verify) | Your result |
|---|---|---|
| Q1 Revenue | ~31,465 orders and ~$109.8M revenue (before tax and freight) | |
| Q2 Trend | Revenue grew from 2012 to 2013 (~$33.5M to ~$43.6M); 2011 and 2014 are partial years; strong seasonality and a sharp channel shift in 2013 | |
| Q3 / Q4 Products | Revenue is led by high-priced bike models (Mountain-200 and Road-series); quantity is led by low-priced accessories (water bottles, tubes, caps, helmets) | |
| Q5 Categories | Bikes generate roughly 85–90% of revenue; Components, Clothing and Accessories are small by comparison | |
| Q6 Customers | Top spenders are reseller stores; individual online customers rarely exceed a few orders | |
| Q7 Territories | Southwest, Canada and Northwest lead; Germany, France and the UK trail among the larger markets | |
| Q8 Salespersons | A handful of salespersons (e.g. Linda Mitchell, Jillian Carson, Michael Blythe) account for a large share of reseller sales | |
| Q9 AOV | ~$3,500 overall, but online orders are far smaller than reseller orders | |
| Q10 Declining products | Older bike models decline as newer models replace them | |
| Q11 Concentration | Top 10 products make up a significant share of total revenue | |
| Q12 Categories by year | Bikes rank first every year; accessories and clothing grow in share after 2012 | |
| Q13 Repeat customers | A minority of customers buy more than once; resellers dominate repeat buying | |
| Q14 Territories | Revenue per customer and online share vary widely across territories | |
| Q15 High volume, low revenue | Cheap accessories and consumables sell in volume but add little revenue | |

---

## 8. Business Recommendations

1. **Protect the bike business.** Bikes drive most revenue; keep stock, pricing and promotions focused on best-selling models and plan for model transitions to avoid revenue dips (Q10).
2. **Bundle high-volume accessories with bikes.** Accessories sell in large quantities for little revenue (Q15); bundling and cross-sell at bike checkout raises order value.
3. **Reduce product concentration risk.** A small set of products drives a large revenue share (Q11); develop mid-tier products and track the top 10 monthly.
4. **Replicate top-territory practices.** Study what works in the leading territories (Q7, Q14) and invest in under-performing ones with growth potential.
5. **Support and coach salespersons.** Reward top performers (Q8) and use their approaches to coach those with lower revenue per order.
6. **Grow repeat purchasing.** Most customers buy once (Q13); introduce loyalty offers, replenishment reminders for consumables and reseller incentives.
7. **Use full-year comparisons when reporting growth.** Because 2011 and 2014 are partial years, report like-for-like periods to avoid misleading conclusions.

---

## Repository Structure

```
adventureworks_project/
├── README.md
├── 01_database_setup.sql     # restore instructions + verification checks
└── 02_analysis_queries.sql   # all analysis queries (Q1–Q15 + bonus)
```

## Tools

SQL Server 2016+ (or Azure SQL / Docker image), SSMS or Azure Data Studio, T-SQL.
